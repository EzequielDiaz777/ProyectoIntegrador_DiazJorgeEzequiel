package com.portfolio.jed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JedApplication {

	public static void main(String[] args) {
		SpringApplication.run(JedApplication.class, args);
	}

}
